# Consistency Log

## 2026-04-23

- Initialized paper-state tracking for the OPRE revision paper.
- Recorded locked Section 6 decisions before applying the next `.tex` edit.
- No figure/table labels were added or removed in this initialization step.
- Re-checked the active state docs after the latest Section 6 wording edits.
- Confirmed that this edit round changed prose/framing only:
  - no new symbols were introduced
  - no results/theorems changed
  - no figure/table/reference labels changed
- Recorded the current locked wording for the Section 6 `\mathrm{tl}` explanation in `overview.md` and `framing.md`.
- Promoted `fig:long_decode` from Appendix B into main-text Section 6 and synchronized the figure/reference registries accordingly.
- Ran a scoped `paper-pipeline` consistency pass on the active Section 6 files and locked the terminology split:
  - `inventory` for realized counts at a stage or segment
  - `system-wide batch-size cap` for `\mathrm{tl}`, `segment-level cap` for `B_k=\Delta l'_k n_k`, and `per-stage threshold` for stage-level controls
- Re-locked the real-data Section 6 exposition so that the body text distinguishes algorithmic segments from any workload discretization and avoids `bins` language in the paper-facing narrative.

## 2026-04-26

- Ran the `update-paper-state` synchronization after the latest Section 6 / Appendix B numerical edits.
- Confirmed this edit round changed prose, captions, appendix tables, and SQL provenance only:
  - no theorem/result statements were added or removed
  - no new math symbols were introduced
  - no figure or table labels were added or removed
- Locked the OR-facing baseline description:
  - vLLM and Sarathi are FCFS-based baselines in these Vidur experiments
  - both use a local capacity-reservation rule before admitting new requests
  - Sarathi's chunked-prefill rule reduces prefill blocking but does not impose a total in-service population cap
- Locked the Appendix B PD-disaggregation description:
  - the experiment uses Vidur's decode-only request generator
  - the workload is `p630d20` with post-prefill context length `630` and decode length `20`
  - Sarathi is not separately reported because chunked prefill does not change decisions in a decode-only setting
- Recorded that repeated-run reproduction configurations are stored in `experiments.db.reproduction_configs` under `run_tag='section6_reproduction_20260426'`.
- Moved `sec:extension` from the main-text sequence to the appendices in the OPRE manuscript.
- Confirmed the structural edit preserves the existing extension labels and updates main-body prose references from `Section~\ref{sec:extension}` to `Appendix~\ref{sec:extension}`.
- Added appendix-specific hyperref anchor names in `LLM_or.tex`; the post-edit compile has no duplicate destination warnings and no undefined references.
- Moved the notation table from Section 2 to Appendix `app:notation` while preserving the table label `tab:notation`.
- Confirmed the model section now references the notation table narratively and introduces the key symbols in the surrounding prose instead of opening with a standalone notation subsection.

## 2026-04-27

- Ran `update-paper-state` after the Section 2--5 terminology synchronization pass.
- Confirmed this edit round changed terminology/framing prose only:
  - no theorem/result statements were added or removed
  - no figure/table labels were added or removed
  - no new mathematical symbols were introduced
- Locked the four-way distinction now used across the paper:
  - `ideal fluid model` for the average-flow approximation
  - `ideal-fluid equilibrium` for the balanced operating point and stage distribution
  - `M^*` for the memory requirement needed to support that equilibrium
  - `realized stability region` for policy-specific or experiment-facing stability comparisons
- Updated `symbols.md`, `framing.md`, `overview.md`, and `changelog.md` accordingly.
- Continued the Section 5 Nested WAIT polish pass.
- Confirmed this edit round changed prose and figure captions only:
  - no theorem/result statements were changed
  - no figure/table labels were added or removed
  - no new mathematical symbols were introduced
- Locked the Section 5 narrative direction: `Algorithm Overview` now starts from the unknown-output-length example, then abstracts to segment-boundary revelation, segment-level coupling, and a logarithmic safety buffer for boundary queues.

## 2026-04-29

- Ran `$verify-proof` on Theorem `thm:nested_wait_heavy_traffic` and its Appendix proof.
- Confirmed the theorem statement remains unchanged:
  - Algorithm `alg:nested_wait` still uses nested prefix waiting, not independent segment service.
  - The memory condition keeps the tighter downstream boundary buffer `n_k+\theta_k^{-1}\log(\cdot)`.
  - Delay metrics use the service-normalized convention recorded in the known-type section.
- Fixed one proof issue found during verification:
  - The high-probability memory step had used the shortcut `V^r <= n_k + max_i S_i`, which is not valid for a reflected random walk after a downward excursion.
  - The proof now uses a finite-horizon Lindley/reflected-random-walk excursion bound with the same `log(1+\zeta T/d_0)` factor.
- Confirmed the deterministic `n_k` boundary term is absorbed by the base memory scale because `n_k<n_{k-1}` and the corresponding boundary-stage memory is already represented in `M^\pi`.
- Ran `$verify-proof` on Theorem `thm:wait_heavy_traffic` and Appendix `appexidx::proof of wait_heavy_traffic`.
- Confirmed the WAIT theorem statement remains unchanged:
  - the nonpositive-drift rate is `O((\zeta T)^(-1/2))` for normalized throughput and `O((\zeta T)^(1/2))` for service-normalized delay;
  - the strict-slack rate is `O(1/(\zeta T))` for normalized throughput and `O(1)` for service-normalized delay.
- Fixed one notation issue:
  - the single-type warm-up no longer redefines `\lambda` as expected arrivals per batch;
  - it now uses `\tilde{\lambda}` for continuous arrival rate, `\mu=\tilde{\lambda}\Delta T` for expected arrivals per batch, and the critical condition `\mu=n`.
- Confirmed the multi-type proof uses the deterministic full-threshold comparison clock only as a conservative comparison process, not as the actual event-driven WAIT batch count.
- Applied the second GPT-Pro proof-audit corrections.
- Confirmed the main WAIT and Nested WAIT theorem statements remain unchanged.
- Locked the memory convention requested by reviewers:
  - prompts waiting before prefill are outside the GPU-resident KV-cache state;
  - prompts already admitted to the GPU but waiting between decode iterations or at Nested WAIT boundaries retain their KV caches and count against memory.
- Confirmed Nested WAIT remains a nested prefix policy in Algorithm `alg:nested_wait`.
- Confirmed the tight downstream memory buffer remains `n_k+\theta_k^{-1}\log(\cdot)` by using the post-review carryover-residual convention.
- Corrected the segment-design extension's first-segment condition to strict slack, matching its `O((\zeta T)^(-1))` throughput and `O(1)` service-normalized delay claims.
